# Linux CI Round

Status: complete
Selected rate: 2

Single-job descriptive AB/BA comparison. All calibration and formal runs are retained.
Pool replicas: 128. Profiling disabled. Linux telemetry interval: 5 seconds.
Calibration: baseline 2/4/8 claims/s for 30 seconds; Ready minimum >=64,
zero cold launches, complete error-free lifecycles, Linux CPU median <=85%.
Lowest-rate failure stops the round. Highest passing rate selects four 60-second ABBA runs.
Latency includes drain; CPU/allocation counters cover the arrival window.
Sampled Ready does not resolve continuous queue availability.
No confidence intervals or significance tests are calculated.

| Run | Status | Rate | Claims | Cold | Ready Min | CPU Median % | p50 ms | p99 ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| ci-cal-r2 | complete | 2 | 44 | 0 | 127 | 55.60121765601218 | 33.213572 | 188.184475 |
| ci-cal-r4 | complete | 4 | 98 | 0 | 114 | 93.87545033453422 | 147.384723 | 685.384486 |
| ci-cal-r8 | complete | 8 | 211 | 50 | 0 | 99.92543347987174 | 1097.089882 | 53772.382938 |
| ci-formal-1-baseline | complete | 2 | 98 | 0 | 124 | 50.909804193861966 | 39.098215 | 187.618256 |
| ci-formal-2-candidate | complete | 2 | 98 | 0 | 123 | 51.92668916016464 | 33.41689 | 231.967577 |
| ci-formal-3-candidate | complete | 2 | 98 | 0 | 122 | 51.252688125086806 | 35.95994 | 204.215467 |
| ci-formal-4-baseline | complete | 2 | 98 | 0 | 123 | 51.329148556694605 | 38.191877 | 143.818649 |

## Pair 1 (AB)

| Measure | Baseline | Candidate | Difference | Change % |
|---|---:|---:|---:|---:|
| p50_ms | 39.098215 | 33.41689 | -5.681325000000001 | -14.530906334214999 |
| p99_ms | 187.618256 | 231.967577 | 44.349321 | 23.638062705369144 |
| controller_cpu_seconds | 5.77 | 5.789999999999999 | 0.019999999999999574 | 0.34662045060658286 |
| controller_alloc_bytes | 1146777496 | 1178165120 | 31387624 | 2.7370282473697882 |

## Pair 2 (BA)

| Measure | Baseline | Candidate | Difference | Change % |
|---|---:|---:|---:|---:|
| p50_ms | 38.191877 | 35.95994 | -2.231936999999995 | -5.844009709185006 |
| p99_ms | 143.818649 | 204.215467 | 60.396817999999996 | 41.995122621406345 |
| controller_cpu_seconds | 5.700000000000001 | 5.840000000000001 | 0.13999999999999968 | 2.4561403508771784 |
| controller_alloc_bytes | 1166573624 | 1176086448 | 9512824 | 0.8154499471179522 |

## Primary Comparison

Two-pair p50 geometric mean ratio: 0.8970745316505427.
Percent change: -10.292546834945728%.
Descriptive only; no confidence interval or significance test.
